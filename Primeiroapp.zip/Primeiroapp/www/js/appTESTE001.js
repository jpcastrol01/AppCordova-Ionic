$('.collection')
	.on('click', '.collection-item', function()
		{				
			hljs.initHighlightingOnLoad();
			
            var colors = ['lightgrey', 'lightblue', 'lightgreen'];            
			var	nomeProduto	= this.firstChild.textContent;
			var isto = this;
            MaterializeCollectionActions.configureActions($('#example-3'), [
                {
                    name: 'exposure_plus_1',
                    callback: function (collectionItem, collection) {
                        //$(collectionItem).remove();
						
						Materialize.toast(nomeProduto +	' ==> adicionado', 1000);
		
						var	$badge = $('.$badge', isto);
						if (badge.length === 0) {
							badge = $('<span class="badge brown-text">0</span>')
							.appendTo(isto);
						}
						
						//$badge.text(parseInt($badge.text()) + 1);
						$(collectionItem).text(parseInt(badge.text()) + 1);
						
                    }
                },
                {
					
					name: 'exposure_neg_1',
                    callback: function (collectionItem, collection) {
                        //$(collectionItem).remove();
						
						Materialize.toast(nomeProduto +	' subtraido', 1000);
		
						var	$badge = $('.$badge', isto);
						if (badge.length === 0) {
							badge = $('<span class="badge brown-text">0</span>')
							.appendTo(isto);
						}
						
						//$badge.text(parseInt($badge.text()) + 1);
						$(collectionItem).text(parseInt(badge.text()) - 1);
						
                    }									
                }						
            ]);
			
			var header = $('header');

            $('.toc-wrapper').pushpin({
                top: header.offset().top + header.height()
            });

            $('.scrollspy').scrollSpy();

			
		/*
			var	nomeProduto	= this.firstChild.textContent;
			Materialize.toast(nomeProduto +	' adicionado', 1000);
			var	$badge = $('.badge', this);
			if ($badge.length === 0) {
				$badge = $('<span class="badge brown-text">0</span>')
				.appendTo(this);
			}
			$badge.text(parseInt($badge.text()) + 1);
		*/
		}
	)
	.on('click', '.badge', function() 
		{
			$(this).remove();
			return false;
		}
	);
	
$('.modal-trigger').leanModal();

$('#confirmar').on('click',	function()	{
								var	texto =	"";
								$('.badge').parent().each(function(){
																texto += this.firstChild.textContent + ': <div></div>';
																texto += this.lastChild.textContent	 + ' ';
															}
														);
								$('#resumo').empty().text(texto);
							}
				);

$('.acao-limpar').on('click', function() {
    $('#numero-mesa').val('');
    $('.badge').remove();
});